titik = (3, 7)
warna = (255, 128, 0)

x, y = titik  # unpacking

print(f"x={x}, y={y}")
print(warna[0], len(warna))

# Baris berikut sengaja dikomentari karena menghasilkan TypeError:
# titik[0] = 10
