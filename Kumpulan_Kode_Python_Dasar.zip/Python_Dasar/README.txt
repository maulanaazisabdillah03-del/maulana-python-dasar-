KUMPULAN KODE PYTHON DASAR

Kode disusun per file berdasarkan contoh pada PDF "Python Dasar".
File diberi nomor agar mudah dipraktikkan berurutan.

Cara menjalankan:
1. Buka folder ini di VS Code.
2. Buka file .py yang ingin dicoba.
3. Pilih Run Python File atau jalankan di terminal:
   python 01_hello.py

Catatan:
- Untuk 15_match.py diperlukan Python 3.10 atau lebih baru.
- Untuk 35_pakai_pandas.py, instal pandas terlebih dahulu:
  python -m pip install pandas
- File baca_data.py, olah_data.py, rekap.py, dan pakai_pandas.py
  memakai file nilai.csv yang ada di folder yang sama.
- Pada 20_tuple.py, baris yang menimbulkan TypeError sengaja dikomentari
  supaya file tetap dapat berjalan. Hapus tanda # jika ingin menguji error itu.
- Contoh kode dari PDF telah dipisah menjadi file kecil agar mudah dipelajari.
