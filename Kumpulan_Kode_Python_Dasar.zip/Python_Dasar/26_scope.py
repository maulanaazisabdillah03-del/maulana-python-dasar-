x = "global"

def tes():
    x = "lokal"  # hanya di dalam tes()
    print(x)

tes()
print(x)
